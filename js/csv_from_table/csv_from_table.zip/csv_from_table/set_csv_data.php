<?php
$data=$_POST['data'];
session_start();
$_SESSION['XX_DATA']=$data;